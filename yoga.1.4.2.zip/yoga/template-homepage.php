<?php 
/**
 // Template Name: Homepage
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @package Yoga
 */
get_header();

    do_action( 'icycp_yoga_homepage_sections', false );
    
get_footer();
?>